//
//  MusicPlayerApp.swift
//  MusicPlayer
//
//  Created by Mayank Bhayana on 08/10/23.
//

import SwiftUI

@main
struct MusicPlayerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
