//
//  ContentView.swift
//  MusicPlayer
//
//  Created by Mayank Bhayana on 08/10/23.
//

import SwiftUI
import AVFoundation


struct MusicPlayer: Identifiable, Equatable {
    let id = UUID()
    let title: String
    let artist: String
    let album: String
    let duration: String
    let fileName: String
    
    static func ==(lhs: MusicPlayer, rhs: MusicPlayer) -> Bool {
        return lhs.id == rhs.id
    }
}

class MusicViewModel: ObservableObject {
    @Published var tracks: [MusicPlayer] = []
    @Published var player: AVAudioPlayer?
    @Published var isPlaying: Bool = false
    @Published var selectedTrack: MusicPlayer?
        
    init() {
        
        tracks = [ MusicPlayer(title: "Music1", artist: "Artist1", album: "Album1", duration: "Duration1", fileName: "Song 1"),
                   MusicPlayer(title: "Music2", artist: "Artist2", album: "Album2", duration: "Duration2", fileName: "Song 2")
        ]
        
    }
    
    func selectedTrack(_ track: MusicPlayer){
        selectedTrack = track
        
    }

    func playTrack(_ track: MusicPlayer) {
        
        guard let myUrl = Bundle.main.url(forResource: track.fileName, withExtension: "mp3") else {
            return
        }
        
        do {
            player = try AVAudioPlayer(contentsOf: myUrl)
       //     player?.delegate = self
            player?.delegate = self as? AVAudioPlayerDelegate
            player?.play()
            isPlaying = true
        }
        catch {
            print("Error in playing audio")
        }
    }
    
    func pauseTrack() {
        player?.pause()
        isPlaying = false
    }
    
    func resumeTrack() {
        player?.play()
        isPlaying = true
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        // Need to implemet logic when track gets finished playing
    }
}

//extension MusicViewModel: AVAudioPlayerDelegate {
//    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
//        // Need to implemet logic when track gets finished playing
//    }
//}

struct TrackDetailView: View {
    @ObservedObject var viewModel: MusicViewModel
    
    var body: some View {
    VStack {
        Text(viewModel.selectedTrack?.title ?? "")
            .font(.largeTitle)
            .padding()
        }
    }
}

struct ContentView: View {
    
    @ObservedObject var viewModel = MusicViewModel()
    
    var body: some View {
        
        NavigationView {
            
            List(viewModel.tracks) { track in
                NavigationLink(destination: Text("Details: \(track.title)")) {
                    VStack(alignment: .leading) {
                        Text(track.title)
                            .font(.headline)
                        Text(track.artist)
                            .font(.subheadline)
                        Text(track.album)
                            .font(.subheadline)
                        Text(track.duration)
                            .font(.subheadline)
                    }
                    .onTapGesture {
                        //                        if viewModel.isPlaying {
                        //                            viewModel.pauseTrack()
                        //                        }
                        //                        else {
                        //                            viewModel.playTrack(track)
                        //                        }
                        
                        viewModel.selectedTrack(track)
                    }
                    .background(
                      NavigationLink(destination: TrackDetailView(viewModel: viewModel), isActive: Binding(
                              get: { viewModel.selectedTrack != nil },
                              set: { _ in viewModel.selectedTrack = nil }
                          )) {
                          EmptyView()
                      }
                      .opacity(0)
                    )
                }
                
                .navigationBarTitle("Music Player")
                .navigationBarItems(trailing:
                                        Button(action: {
                    if viewModel.isPlaying{
                        viewModel.pauseTrack()
                    }
                    else{
                        viewModel.resumeTrack()
                    }
                }) {
                    Image(systemName: viewModel.isPlaying ? "Pause Circle" : "Play Circle")
                        .font(.system(size: 25))
                }
                )
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
